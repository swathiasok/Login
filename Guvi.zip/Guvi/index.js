const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const app = express();
mongoose.connect(
  "mongodb+srv://admin-Sriram:Sriram@27@cluster0.hjzur.mongodb.net/AccountsDB",
  {
    useUnifiedTopology: true,
    useNewUrlParser: true,
  }
);

const accountsSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: [true, "No name specified!"],
  },
  lastName: String,
  phnNumber: Number,
  email: {
    type: String,
    required: [true, "No email specified!"],
  },
  password: {
    type: String,
    required: [true, "No password specified!"],
  },
});

const Account = mongoose.model("Account", accountsSchema);

app.set("view engine", "ejs");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("Public"));

app.get("/", function (req, res) {
  let msg = " ";
  res.render("index", { msgCheck: msg });
});

app.post("/", function (req, res) {
  if (req.body.signInSubmit === "signedIn") {
    Account.findOne({ email: req.body.email }, function (err, document) {
      if (document !== null) {
        if (req.body.pass === document.password) {
          res.render("details.ejs", {
            userId: document._id,
            userFirstName: document.firstName,
            userLastName: document.lastName,
            userNumber: document.phnNumber,
            userEmail: document.email,
            userPassword: document.password,
          });
        }
      } else {
        res.render("index", { msgCheck: "wrongCredentials" });
      }
    });
  } else if (req.body.signUpSubmit === "signedUp") {
    const account = new Account({
      firstName: req.body.fName,
      lastName: req.body.lName,
      phnNumber: req.body.pNumber,
      email: req.body.mail,
      password: req.body.pass,
    });
    account.save();
    res.redirect("/");
  } else if (req.body.updateSave === "updateData") {
    console.log("hi");
    Account.updateOne(
      { _id: req.body.userId },
      {
        firstName: req.body.updatedFirstName,
        lastName: req.body.updatedLastName,
        phnNumber: req.body.updatedNumber,
        email: req.body.updatedEmail,
        password: req.body.updatedPassword,
      },
      function (err, docs) {
        if (err) {
          console.log(err);
        } else {
          console.log("Updated Docs : ", docs);
        }
      }
    );
    Account.findOne({ _id: req.body.userId }, function (err, document) {
      res.render("details.ejs", {
        userId: document._id,
        userFirstName: document.firstName,
        userLastName: document.lastName,
        userNumber: document.phnNumber,
        userEmail: document.email,
        userPassword: document.password,
      });
    });
  } else {
    res.redirect("/");
  }
});

let port = process.env.PORT;
if (port == null || port == "") {
  port = 3000;
}

app.listen(port, function (req, res) {
  console.log("Sucessful ra !");
});
