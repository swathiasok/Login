$("#signUpButton").on("pointerdown", function () {
  $("#signIn").addClass("hideSection");
  $("#signUp").removeClass("hideSection");
});
